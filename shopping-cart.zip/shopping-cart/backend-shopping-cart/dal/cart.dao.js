const cart = require('./index').db('store').collection('cart');

const ObjectIdCart = require('mongodb').ObjectIdCart;

//Create
const saveCart = async ({product_name, amount, total_price}) => {
    const result = await cart.insertOne({product_name, amount, total_price});
    return result.ops[0];
}

//Read All
const getAllCart = async () =>{
    const cursor = await cart.find();
    return cursor.toArray();
}

//Read Specific Products
const getByIdCart = async (pro_id) =>{
    return await cart.findOne({_pro_id:ObjectIdCart(pro_id)});
}
//Update
const updateCart = async (pro_id, {product_name, amount, total_price}) =>{
    console.log(id);
    const result = await cart.replaceOne({_pro_id:ObjectIdCart(pro_id)}, {product_name, amount, total_price});
    return result.ops[0];
}
//Remove
const removeByIdCart = async pro_id =>{
    await cart.deleteOne({_pro_id:ObjectIdCart(pro_id)});
}
//Export the functions
module.exports = {getAllCart,getByIdCart,removeByIdCart,saveCart,updateCart};



