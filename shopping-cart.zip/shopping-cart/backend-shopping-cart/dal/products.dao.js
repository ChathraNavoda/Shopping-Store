const products = require('./index').db('store').collection('products');

const ObjectId = require('mongodb').ObjectId;

//Create
const save = async ({name, description, qty, price}) => {
    const result = await products.insertOne({name ,description, qty, price});
    return result.ops[0];
}

//Read All
const getAll = async () =>{
    const cursor = await products.find();
    return cursor.toArray();
}

//Read Specific Products
const getById = async (id) =>{
    return await products.findOne({_id:ObjectId(id)});
}
//Update
const update = async (id, {name,description,qty,price}) =>{
    console.log(id);
    const result = await products.replaceOne({_id:ObjectId(id)}, {name,description,qty,price});
    return result.ops[0];
}
//Remove
const removeById = async id =>{
    await products.deleteOne({_id:ObjectId(id)});
}
//Export the functions
module.exports = {getAll,getById,removeById,save,update};



