const Koa = require('Koa');
const bodyParser = require('koa-bodyparser');
const productRoutes = require('./routes/products.routes');
const cartRoutes = require('./routes/cart.routes');

const app = new Koa();

app.use(bodyParser());
app.use(productRoutes.routes()).use(productRoutes.allowedMethods());
app.use(cartRoutes.routes()).use(cartRoutes.allowedMethods());
app.listen(3040);
console.log("Application is running on port 3040");



