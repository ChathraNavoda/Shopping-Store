const Router = require("@koa/router");
const {createCart, getCart,updateCart,deleteCart} =  require('../api/cart.api');

const router = new Router({
    prefix:'/cart'
})
//GET request
router.get('/',async ctx=>{
    ctx.body= await getCart() ;
})
//POST request
router.post('/',async ctx=>{
    let cart = ctx.request.body;
    cart = await createCart(cart);
    ctx.response.status = 210;
    ctx.body = cart;
})
//GET request 
router.get('/:pro_id',async ctx=>{
    const pro_id = ctx.params.pro_id;
    ctx.body = await getCart(pro_id);
})
//Delete Request
router.delete('/:pro_id',async ctx=>{
    //Get the id from the url
    const pro_id = ctx.params.pro_id;
    await deleteCart(pro_id);
})
//Update request
router.put('/:pro_id',async ctx=>{
    const pro_id = ctx.params.pro_id;
    let cart = ctx.request.body;
    cart = await updateCart(pro_id,cart);
    ctx.response.status = 210;
    ctx.body = cart;

})
module.exports = router;