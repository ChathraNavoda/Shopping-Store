//Import the methods that we exported in products.dao.js
const {getAll, getById, removeById, save, update} = require('../dal/products.dao');

//Map the save() method
const createProduct = async ({name, description, qty, price}) => {
    const product = {
        name,
        description,
        qty,
        price
    }
    return await save(product);
}
//Map the getAll() method
const getProducts = async ()=>{
    //
    return await getAll();
}
//Map the getById() method
const getProduct = async id =>{
    return await getById(id);
}
//Map the removeById() method
const deleteProduct = async id =>{
    return await removeById(id);
}
const updateProduct = async (id,{name, description, qty, price})=>{
    return await update(id,{name, description, qty, price});
}

module.exports = {
    createProduct,
    getProducts,
    getProduct,
    deleteProduct,
    updateProduct
}
