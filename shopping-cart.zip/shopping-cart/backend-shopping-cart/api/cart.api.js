//Import the methods that we exported in products.dao.js
const {getAllCart, getByIdCart, removeByIdCart, save, update_cart} = require('../dal/cart.dao');

//Map the save() method
const createCart = async ({product_name, amount, total_price}) => {
    const cart = {
        product_name,
        amount,
        total_price
    }
    return await save(cart);
}
//Map the getAllCart() method   
const getCarts = async ()=>{
    //
    return await getAllCart();
}
//Map the getById() method
const getCart = async pro_id =>{
    return await getByIdCart(pro_id);
}
//Map the removeById() method
const deleteCart = async pro_id =>{
    return await removeByIdCart(pro_id);
}
const updateCart = async (pro_id,{product_name, amount, total_price})=>{
    return await update_cart(pro_id,{product_name, amount, total_price});
}

module.exports = {
    createCart,
    getCarts,
    getCart,
    getByIdCart,
    deleteCart,
    updateCart
}

